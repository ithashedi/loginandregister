package com.android.loginandregisterfirebase;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;




// this is where you add declare the types
public class Register extends AppCompatActivity {
// declaring the the types
    TextView tvFullName;
    TextView tvEmail;
    TextView tvPassword;
    TextView tvPhone;
    Button btnRegister;
    TextView tvLoginBtn;
    ProgressBar progressBar;
    FirebaseAuth fAth;
    String userID;
    // declaring the instance of the firestore
    FirebaseFirestore fstore;


    // this is wehre you declare the varibles and get them from the interface
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        tvFullName = findViewById(R.id.tvFullName);
        tvEmail = findViewById(R.id.tvEmailReg);
        tvPassword = findViewById(R.id.tvPasswordReg);
        tvPhone = findViewById(R.id.tvPhoneReg);
        btnRegister = findViewById(R.id.btnRegisterReg);
        tvLoginBtn = findViewById(R.id.tvLoginReg);
        fAth = FirebaseAuth.getInstance();
        // for the firestore
        fstore = FirebaseFirestore.getInstance();





        // when click login it should take the user to the login page
        tvLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login.class));
            }
        });


        // we are adding an event listner  to the register button that will do all the checks
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = tvEmail.getText().toString().trim();
                String password = tvPassword.getText().toString().trim();

                // other data such as full name and phone number

                String fullName = tvFullName.getText().toString();
                String phone = tvPhone.getText().toString();

                // this where we check if the email is enterd or not if not entered it will send an error massage saying " email required"
                if (TextUtils.isEmpty(email)){
                    tvEmail.setError("Email is required");
                    return;
                }
                if (TextUtils.isEmpty(password)){
                    tvPassword.setError("Password is required");
                    return;
                }
                if (password.length()<7){
                    tvPassword.setError("Password must be 7 characters long");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                //here we are checking if the user is alreayd register if not should redirected
                if (fAth.getCurrentUser() != null){
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    finish();
                }

                // here we are registering the user

                fAth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Register.this, "User Created", Toast.LENGTH_SHORT).show();

                            //getting the user id
                            userID = fAth.getCurrentUser().getUid();
                            DocumentReference documentReference = fstore.collection("users").document(userID);
                            //create a map

                            Map<String, Object> user = new HashMap<>();

                            // writing the data

                            user.put("fName", fullName);
                            user.put("email", email);
                            user.put("phone", phone);

                            // saveing the data in firstore and checking
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d( "TAG", "OnSucces: user profile is created for " + userID);
                                }
                            });

                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        }

                        else {
                            Toast.makeText(Register.this, "Error!" + task.getException(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });
        tvLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login.class));
            }
        });
    }
}









