package com.android.loginandregisterfirebase;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.EventListener;

public class MainActivity extends AppCompatActivity {


    Button logoutBtnHome;
    TextView fulName, email, phone;
    FirebaseAuth fAuth;
    FirebaseFirestore fstore;
    String userID;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phone = findViewById(R.id.profilePhoneNumber);
        fulName = findViewById(R.id.profileName);
        email = findViewById(R.id.profileEmailAddress);
        fAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();


        DocumentReference documentReference = fstore.collection("users").document(userID);

        documentReference.addSnaptshotListener(this,
                new EventListener<DocumentSnapshot>(){
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e){
                        phone.setText(documentSnapshot.getString("phone"));
                        fulName.setText(documentSnapshot.getString("fName"));
                        email.setTxet(documentSnapshot.getString("email"));
                    }
                });

        // Use get methods
    }


    logoutBtnHome = findViewById(R.id.logoutBtnHome);

    }
}