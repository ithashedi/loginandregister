package com.android.loginandregisterfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {


    // here we are declaring the types

    TextView tvEmailLog;
    TextView tvPasswordLog;
    Button btnLoginLog;
    Button btCreateNewLog;
    FirebaseAuth fAuth;
    ProgressBar progressBar;



    // here decalring the variables
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        tvEmailLog = findViewById(R.id.tvEmailLog);
        tvPasswordLog = findViewById(R.id.tvPasswordLog);
        btnLoginLog = findViewById(R.id.btnLoginLog);
        btCreateNewLog = findViewById(R.id.btCreatenewLog);
        // here we adding the firebase authentaction varibel
        fAuth = FirebaseAuth.getInstance();

        // here we are adding the event listner to the button that will do the checks
        btnLoginLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fAuth = FirebaseAuth.getInstance();
                // declaring our strings
                String emailLog = tvEmailLog.getText().toString().trim();
                String passwordLog = tvPasswordLog.getText().toString().trim();
                // we are checking if the if the email box has not been entered
                if (TextUtils.isEmpty(emailLog)) {
                    // here we are displying the error
                    tvEmailLog.setError("Email is required");
                    return;
                }

                fAuth.signInWithEmailAndPassword(emailLog, passwordLog).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                    @Override

                    public void onComplete(@NonNull Task<AuthResult> task) {
                        // here we are checking if the details match if yes the user will be sent to the main page
                        if (task.isSuccessful()) {
                            Toast.makeText(Login.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            // if not it will disply the error
                        } else {
                            Toast.makeText(Login.this, "Error!" + task.getException(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }

                    }


                });

                // here we are adding the event to the create new account button and should direct the user to the register page
                btCreateNewLog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(getApplicationContext(), Register.class));
                    }
                });

            }
        });}}
